<?php
include('config.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM doctors WHERE id=$id");
    $doctor = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $specialty = $_POST['specialty'];
    $hospital_location = $_POST['hospital_location'];
    $date_of_birth = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];

    $query = "UPDATE doctors SET name='$name', phone='$phone', specialty='$specialty', 
              hospital_location='$hospital_location', date_of_birth='$date_of_birth', 
              gender='$gender', email='$email' WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        header('Location: manage_doctors.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Doctor</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>
<body>
    <input type="checkbox" id="check">
    <label for="check">
        <i class="fas fa-bars" id="btn"></i>
        <i class="fas fa-times" id="cancel"></i>
    </label>
    <div class="sidebar">
        <header>Admin Dashboard</header>
        <ul>
            <li><a href="../view/admin_dashboard.php"><i class="fas fa-qrcode"></i>Manage Patients</a></li>
            <li><a href="manage_doctor.php"><i class="fas fa-link"></i>Manage Doctors</a></li>
            <li><a href="#"><i class="fas fa-stream"></i>Manage Appointments</a></li>
            <li><a href="#"><i class="fas fa-calendar-week"></i>View Payment History</a></li>
        </ul>
    </div>
    <section class="content">
        <div class="container-content">
            <h1>Edit Doctor</h1>
            <form action="edit_doctor.php?id=<?php echo $doctor['id']; ?>" method="POST">
                <table>
                    <tr>
                        <td><label for="name">Name:</label></td>
                        <td><input type="text" id="name" name="name" value="<?php echo htmlspecialchars($doctor['name']); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="phone">Phone:</label></td>
                        <td><input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($doctor['phone']); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="specialty">Specialty:</label></td>
                        <td><input type="text" id="specialty" name="specialty" value="<?php echo htmlspecialchars($doctor['specialty']); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="hospital_location">Hospital Location:</label></td>
                        <td><input type="text" id="hospital_location" name="hospital_location" value="<?php echo htmlspecialchars($doctor['hospital_location']); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="date_of_birth">Date of Birth:</label></td>
                        <td><input type="date" id="date_of_birth" name="date_of_birth" value="<?php echo htmlspecialchars($doctor['date_of_birth']); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="gender">Gender:</label></td>
                        <td><input type="text" id="gender" name="gender" value="<?php echo htmlspecialchars($doctor['gender']); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="email">Email:</label></td>
                        <td><input type="email" id="email" name="email" value="<?php echo htmlspecialchars($doctor['email']); ?>" required></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center;"><button type="submit">Update Doctor</button></td>
                    </tr>
                </table>
            </form>
        </div>
    </section>
</body>
</html>