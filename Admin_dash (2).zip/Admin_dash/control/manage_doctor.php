<?php
include('config.php'); // Ensure this connects to your database properly

// Fetch all doctor data
$doctors = mysqli_query($conn, "SELECT * FROM doctors");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors</title>
    <link rel="stylesheet" href="style.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" /> -->
</head>

<body>
   
<body>
    <input type="checkbox" id="check">
    <label for="check">
        <i class="fas fa-bars" id="btn"></i>
        <i class="fas fa-times" id="cancel"></i>
    </label>
    <div class="sidebar">
        <header>Admin Dashboard</header>
        <ul>
            <li><a href="../view/admin_dashboard.php"><i class="fas fa-qrcode"></i>Manage Patients</a></li>
            <li><a href="manage_doctor.php"><i class="fas fa-link"></i>Manage Doctors</a></li>
            <li><a href="#"><i class="fas fa-stream"></i>Manage Appointments</a></li>
            <li><a href="#"><i class="fas fa-calendar-week"></i>View Payment History</a></li>
        </ul>
    </div>
    <section class="content">
        <div class="container-content">
            <h1>Manage Doctors</h1>
            <!-- Doctors Section -->
            <section id="doctors" class="active">
                <table border="1" cellpadding="10" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Specialty</th>
                            <th>Hospital Location</th>
                            <th>Date of Birth</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($doctor = mysqli_fetch_assoc($doctors)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($doctor['name']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['phone']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['specialty']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['hospital_location']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['date_of_birth']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['gender']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['email']); ?></td>
                            <td>
                                <a href="edit_doctor.php?id=<?php echo $doctor['id']; ?>">Edit</a> |
                                <a href="delete_doctor.php?id=<?php echo $doctor['id']; ?>">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </section>
        </div>
    </section>
</body>

</html>