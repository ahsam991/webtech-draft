<?php
    session_start();
    require_once('../model/userModel.php');
    if(isset($_REQUEST['submit']))
    {
        
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_REQUEST['email']);
        $phone = trim($_REQUEST['phone']);
        $nid = trim($_REQUEST['nid']);
        $pass = trim($_REQUEST['password']);
        $dob = $_REQUEST['dob'];
        $gender = '';
        if (isset($_POST['gender']))
        {
            $gender = $_POST['gender'];
        }
        $address = trim($_REQUEST['address']);
        $med_history = trim($_REQUEST['med_history']);
        $emergency_contact = trim($_REQUEST['emergency_contact']);

        $status = addUser($first_name, $last_name, $email, $phone, $nid, $pass, $dob, $gender,$address, $med_history, $emergency_contact);

        if($status)
        {
            header("Location: ../view/login.html");
        }
        else{
            header("Location: ../view/sign_up.html");
        }
    }

    ?>

