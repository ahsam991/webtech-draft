<?php
session_start();
require_once('../model/appointBookingModel.php');

if (isset($_REQUEST['book'])) {
    $problem = $_REQUEST['problem'];
    $doctor_id = $_REQUEST['doctor'];
    $date = $_REQUEST['date'];
    $name = $_SESSION['name'];
    $email = $_SESSION['email'];

    if (empty($problem) || empty($doctor_id) || empty($date)) {
        echo "All fields are required!";
        exit;
    }

    // Fetch doctor details for the selected ID
    $conn = getConnection();
    $sql = "SELECT name, available_time FROM doctor_info WHERE id = '{$doctor_id}'";
    $result = mysqli_query($conn, $sql);
    $doctor = mysqli_fetch_assoc($result);
    $doctor_name = $doctor['name'];
    $available_time = $doctor['available_time'];
    mysqli_close($conn);

    $tokenCount = checkAppointmentSlot($doctor_id, $date);

    if ($tokenCount >= 30) {
        echo "Sorry, the slot is full. Please select another time or date.";
    } else {
        $result = bookAppointment($name, $email, $problem, $doctor_id, $doctor_name, $available_time, $date);
        if ($result) {
            echo "Appointment booked successfully. Your token number is: " . ($tokenCount + 1);
        } else {
            echo "Error booking the appointment or you have already requested an appointment.";
        }
    }
}
?>
