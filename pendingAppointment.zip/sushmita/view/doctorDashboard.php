<html>
    <head></head>

    <body>
        <h1>DOCTOR DASHBOARD</h1>
        <a href="appointmentHistory.php">view appointment history</a>
    </body>
    
</html>