<html>
    <head></head>

    <body>
        <h1>PATIENT DASHBOARD</h1>
        <a href = "userProfileView.php">view profile</a> <br>
        <a href = "appointmentBooking.php">Book Appointment</a>
        <a href="appointmentHistory.php">view appointment history</a>
    </body>
    
</html>