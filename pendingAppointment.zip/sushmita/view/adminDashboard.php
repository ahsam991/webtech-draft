
<html>
    <head></head>

    <body>
        <h1>ADMIN DASHBOARD</h1>
        <!-- <a href="appointmentHistory.php">view appointment history</a> -->

        <a href="adminAppointments.php">Pending appointment </a>


    </body>

</html>
