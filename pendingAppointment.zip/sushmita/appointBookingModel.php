<?php
session_start();

function getConnection()
{
    $conn = mysqli_connect('localhost', 'root', '', 'web_project');
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

// Fetch doctors to populate the dropdown
function selectDoctor()
{
    $conn = getConnection();
    $sql = "SELECT id, name, available_time FROM doctor_info";
    $result = mysqli_query($conn, $sql);

    if ($result === false) {
        echo "Error in query: " . mysqli_error($conn);
    } else {
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value=\"{$row['id']}\">Dr. {$row['name']} ({$row['available_time']})</option>";
            }
        } else {
            echo "<option>No doctors available</option>";
        }
    }
    mysqli_close($conn);
}

// Check appointment slots for a doctor and date
function checkAppointmentSlot($doctor_id, $date)
{
    $conn = getConnection();
    $sql = "SELECT COUNT(*) as token_count FROM appointment_request WHERE doctor_id = '{$doctor_id}' AND appointment_date = '{$date}'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    mysqli_close($conn);

    return $row['token_count'];
}

// Insert an appointment request
function insertAppointmentRequest($name, $email, $problem, $doctor_id, $doctor_name, $available_time, $date, $token)
{
    $conn = getConnection();
    $sql = "INSERT INTO appointment_request (name, email, problem, doctor_id, doctor_name, available_time, appointment_date, token) 
            VALUES ('{$name}', '{$email}', '{$problem}', '{$doctor_id}', '{$doctor_name}', '{$available_time}', '{$date}', '{$token}')";
    $result = mysqli_query($conn, $sql);
    mysqli_close($conn);

    return $result;
}

// Book appointment by validating and storing
function bookAppointment($name, $email, $problem, $doctor_id, $doctor_name, $available_time, $date)
{
    $conn = getConnection();
    $checkSql = "SELECT * FROM appointment_request WHERE email = '{$email}'";
    $checkResult = mysqli_query($conn, $checkSql);
    if (mysqli_num_rows($checkResult) > 0) {
        mysqli_close($conn);
        return false;
    }

    mysqli_close($conn);

    $tokenCount = checkAppointmentSlot($doctor_id, $date) + 1;
    return insertAppointmentRequest($name, $email, $problem, $doctor_id, $doctor_name, $available_time, $date, $tokenCount);
}
?>
